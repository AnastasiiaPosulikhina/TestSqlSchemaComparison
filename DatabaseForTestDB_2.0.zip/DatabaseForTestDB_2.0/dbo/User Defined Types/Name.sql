﻿CREATE TYPE [dbo].[Name]
    FROM NVARCHAR (50) NULL;

