﻿CREATE TYPE [dbo].[AccountNumber]
    FROM NVARCHAR (15) NULL;

